<?php
declare(strict_types=1);
require_once __DIR__ . '/../helpers/bootstrap.php';
require_once __DIR__ . '/../middleware/auth.php';
Request::requireMethod('GET');
requireAuth();
$db = Database::getConnection();
$active = $db->query("SELECT p.*, COUNT(t.id) transaction_count,
    COALESCE(SUM(CASE WHEN t.type='income' THEN t.amount ELSE 0 END),0) total_income,
    COALESCE(SUM(CASE WHEN t.type='expense' THEN t.amount ELSE 0 END),0) total_expenses
    FROM financial_periods p LEFT JOIN transactions t ON t.period_id=p.id
    WHERE p.status='active' GROUP BY p.id ORDER BY p.start_date DESC LIMIT 1")->fetch();
$rows = $db->query("SELECT p.*, COUNT(t.id) transaction_count,
    COALESCE(SUM(CASE WHEN t.type='income' THEN t.amount ELSE 0 END),0) total_income,
    COALESCE(SUM(CASE WHEN t.type='expense' THEN t.amount ELSE 0 END),0) total_expenses
    FROM financial_periods p LEFT JOIN transactions t ON t.period_id=p.id
    WHERE p.status='archived' GROUP BY p.id ORDER BY p.start_date DESC LIMIT 100")->fetchAll();
$transform = static function(array $p): array { $p['id']=(int)$p['id']; $p['transaction_count']=(int)$p['transaction_count']; $p['total_income']=(float)$p['total_income']; $p['total_expenses']=(float)$p['total_expenses']; $p['net_income']=$p['total_income']-$p['total_expenses']; return $p; };
Response::success('Financial periods loaded.', ['active' => $active ? $transform($active) : null, 'archived' => array_map($transform, $rows)]);
